import Lean

def main (args : List String) : IO Unit := do
  let input := args.head!
  let paths ← IO.FS.lines input
  for path in paths do
    let header ← Lean.parseImports' (← IO.FS.readFile path) path
    let imports := header.imports.toList.map (fun i => i.module.toString)
    IO.println (Lean.Json.compress (Lean.Json.mkObj
      [("path", Lean.toJson path), ("imports", Lean.toJson imports)]))
