#!/usr/bin/env python3
"""Check manifest-listed public file bytes. This does not check Lean proofs."""
import argparse
import hashlib
import json
import pathlib
import re
import sys


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest().upper()


def inside(root, relative):
    name = pathlib.PurePosixPath(relative)
    if not relative or "\\" in relative or ":" in relative or name.is_absolute() or ".." in name.parts:
        raise ValueError("Manifest entry is not a safe relative name.")
    result = root.joinpath(*name.parts).resolve()
    if not result.is_relative_to(root):
        raise ValueError("Manifest entry escapes the evidence directory.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=pathlib.Path)
    parser.add_argument("--manifest", choices=["EVIDENCE_FILES_SHA256.json", "PUBLIC_COPY_MANIFEST.json"],
                        help="Default: full payload manifest if available, otherwise public-copy manifest")
    parser.add_argument("--expected-manifest-sha256", help="Optional checksum obtained separately")
    args = parser.parse_args()
    root = args.directory.resolve()
    manifest_name = args.manifest or ("EVIDENCE_FILES_SHA256.json" if (root / "EVIDENCE_FILES_SHA256.json").is_file()
                                     else "PUBLIC_COPY_MANIFEST.json")
    manifest_path = root / manifest_name
    actual_manifest_hash = digest(manifest_path)
    if args.expected_manifest_sha256:
        expected = args.expected_manifest_sha256.upper()
        if not re.fullmatch(r"[0-9A-F]{64}", expected) or actual_manifest_hash != expected:
            raise ValueError("The public-copy manifest checksum differs from the supplied checksum.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    entries = manifest["files"]
    if not isinstance(entries, list) or not entries:
        raise ValueError("The manifest has no file entries.")
    seen = set()
    for entry in entries:
        relative = entry["path"]
        key = relative.casefold()
        if key in seen:
            raise ValueError("Duplicate or case-colliding manifest entry.")
        seen.add(key)
        expected = entry["publicSha256" if manifest_name == "PUBLIC_COPY_MANIFEST.json" else "sha256"].upper()
        if not re.fullmatch(r"[0-9A-F]{64}", expected):
            raise ValueError("Invalid public SHA-256 field.")
        source = inside(root, relative)
        if not source.is_file() or digest(source) != expected:
            raise ValueError("A manifest-listed public file is missing or has changed: " + relative)
        if source.stat().st_size != entry["publicBytes" if manifest_name == "PUBLIC_COPY_MANIFEST.json" else "bytes"]:
            raise ValueError("A public file has the wrong byte length: " + relative)
    print(f"FILE INTEGRITY OK: {len(entries)} manifest-listed public files match.")
    print(manifest_name + " SHA-256: " + actual_manifest_hash)
    print("This does not verify private original bytes, unlisted files, or Lean proofs.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("FILE INTEGRITY CHECK FAILED: " + str(error), file=sys.stderr)
        raise SystemExit(1)
