#!/usr/bin/env python3
"""Compile the frozen source closure into an empty output tree. No kernel replay."""
import argparse
import datetime
import hashlib
import heapq
import json
import os
import pathlib
import re
import subprocess
import sys
import time


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest().upper()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def inside(root, relative):
    name = pathlib.PurePosixPath(relative)
    require(relative and "\\" not in relative and ":" not in relative and not name.is_absolute()
            and ".." not in name.parts, "Unsafe relative plan path.")
    result = root.joinpath(*name.parts).resolve()
    require(result.is_relative_to(root), "A source or output path escapes the reproduction root.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=pathlib.Path, default=pathlib.Path("."))
    parser.add_argument("--plan", type=pathlib.Path, required=True)
    parser.add_argument("--toolchain", type=pathlib.Path, required=True)
    parser.add_argument("--check-state", action="store_true", help="Only recheck a completed local source build's source/artifact hashes")
    args = parser.parse_args()
    root = args.root.resolve()
    toolchain = args.toolchain.resolve()
    lean = toolchain / "bin" / ("lean.exe" if os.name == "nt" else "lean")
    require(root.is_dir() and lean.is_file(), "The reproduction root or matching compiler is missing.")
    plan = json.loads(args.plan.read_text(encoding="utf-8-sig"))
    modules = {item["name"]: item for item in plan["modules"]}
    require(len(modules) == len(plan["modules"]) == plan["totalModules"] == 3229,
            "Expected the original 3,229-module plan without duplicate names.")
    require(sum(item["package"] == "project" for item in modules.values()) == 255,
            "Expected 251 mathematical project modules and four roots/audits.")
    require(sum(name.startswith("AutomaticContinuity.") for name in modules) == 251,
            "The mathematical project module count differs.")
    require({"AutomaticContinuity", "Audit", "CompletionAudit", "FreshVerification"} <= modules.keys(),
            "A required root or audit module is missing.")
    build = root / "build"
    records = root / "reproduction-records"
    if args.check_state:
        summary = json.loads((records / "build-summary.json").read_text(encoding="utf-8"))
        require(summary["status"] == "SOURCE BUILD COMPLETE", "The local source build is not complete.")
        require(summary["planSha256"] == digest(args.plan) and summary["compilerSha256"] == digest(lean),
                "The local build plan or compiler changed.")
        require(len(summary["modules"]) == len(modules)
                and {entry["module"] for entry in summary["modules"]} == modules.keys(),
                "The local build summary does not cover the complete source plan.")
        for entry in summary["modules"]:
            item = modules[entry["module"]]
            require(entry["status"] == "PASS" and entry["exitCode"] == 0, "A local compilation did not succeed.")
            require(entry["source"] == item["source"], "A build record names a different source from the plan.")
            require(digest(inside(root, item["source"])) == entry["sourceSha256Before"]
                    == entry["sourceSha256After"] == item["sha256"].upper(), "A compiled source changed.")
            expected_olean = "build/" + entry["module"].replace(".", "/") + ".olean"
            require(bool(entry["artifacts"]) and expected_olean in {a["path"] for a in entry["artifacts"]},
                    "A build record is missing the module's expected .olean artifact.")
            for artifact in entry["artifacts"]:
                require(digest(inside(root, artifact["path"])) == artifact["sha256"], "A local build artifact changed.")
        print("LOCAL BUILD IDENTITY OK. No kernel replay or proof verification was performed by this command.")
        return 0
    require(not build.exists() or not any(build.iterdir()), "Use an empty build directory; this helper does not resume.")
    require(not records.exists(), "Preserve previous reproduction records; use a new reproduction root.")
    for item in modules.values():
        require(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_'.]*", item["name"]), "Invalid module name in plan.")
        source = inside(root, item["source"])
        package_root = inside(root, item["root"])
        require(inside(package_root, item["relativePath"]) == source, "Plan source and package-relative source disagree.")
        require(source.is_file() and digest(source) == item["sha256"].upper(),
                "Planned source hash mismatch: " + item["name"])
    for source in (root / "source").rglob("*"):
        require(not source.is_symlink(), "Materialise source links as described in the package records.")
        if source.is_file():
            require(not source.name.endswith((".olean", ".olean.private", ".olean.server", ".ilean",
                                               ".ir", ".ir.sig", ".dll", ".o", ".obj")),
                    "Compiled artifacts must not be copied into the source tree.")
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("LEAN", "LAKE", "MATHLIB"))}
    env["LEAN_PATH"] = str(build)
    env["PATH"] = str(toolchain / "bin") + os.pathsep + env.get("PATH", "")
    env.update(MATHLIB_NO_CACHE_ON_UPDATE="1", LAKE_NO_CACHE="1", LEAN_NUM_THREADS="1")
    version = subprocess.run([str(lean), "--version"], env=env, capture_output=True, text=True, check=True).stdout.strip()
    require("4.34.0-rc2" in version and "6a10ac8c22beadecabdbb0919c2b50214762f91d" in version,
            "The compiler release or full commit does not match the pinned toolchain.")

    # Only plan-internal imports are scheduled; others must belong to the retained toolchain.
    dependencies = {name: {dep for dep in item["imports"] if dep in modules}
                    for name, item in modules.items()}
    dependents = {name: [] for name in modules}
    for name, item in modules.items():
        for dep in item["imports"]:
            if dep not in modules:
                require((toolchain / "lib/lean" / (dep.replace(".", "/") + ".olean")).is_file(),
                        "An import is outside the plan and retained toolchain: " + dep)
        for dep in dependencies[name]:
            dependents[dep].append(name)
    ready = [name for name in modules if not dependencies[name]]
    heapq.heapify(ready)
    order = []
    while ready:
        name = heapq.heappop(ready)
        order.append(name)
        for child in dependents[name]:
            dependencies[child].remove(name)
            if not dependencies[child]:
                heapq.heappush(ready, child)
    require(len(order) == len(modules), "The build plan contains an import cycle.")

    build.mkdir(exist_ok=True)
    records.mkdir()
    summary = {"status": "RUNNING", "stage": "source compilation only", "kernelReplayRun": False,
               "startedUtc": utc(), "planSha256": digest(args.plan), "compilerSha256": digest(lean),
               "compilerVersion": version, "nonToolchainSearchPath": ["build"], "modules": []}
    write(records / "build-summary.json", summary)
    for index, name in enumerate(order, 1):
        item = modules[name]
        source = inside(root, item["source"])
        require(digest(source) == item["sha256"].upper(), "Source changed before compilation: " + name)
        output_relative = "build/" + name.replace(".", "/") + ".olean"
        output = inside(root, output_relative)
        output.parent.mkdir(parents=True, exist_ok=True)
        flags = ["-j1", "-M6144"]
        if item["package"] in ("project", "mathlib"):
            flags.append("-DautoImplicit=false")
        if item["package"] == "mathlib":
            flags.extend(["-DmaxSynthPendingDepth=3", "-Dpp.unicode.fun=true"])
        record = {"module": name, "source": item["source"], "sourceSha256Before": digest(source),
                  "startedUtc": utc(), "status": "RUNNING", "argumentsAreLocationNormalised": True,
                  "arguments": flags + [item["relativePath"], "-o", output_relative]}
        write(records / (name + ".json"), record)
        start = time.monotonic()
        with (records / (name + ".stdout.txt")).open("wb") as out, (records / (name + ".stderr.txt")).open("wb") as err:
            result = subprocess.run([str(lean), *flags, item["relativePath"], "-o", str(output)],
                                    cwd=inside(root, item["root"]), env=env, stdout=out, stderr=err, check=False)
        record.update(exitCode=result.returncode, finishedUtc=utc(), elapsedSeconds=time.monotonic() - start,
                      sourceSha256After=digest(source))
        okay = result.returncode == 0 and output.is_file() and record["sourceSha256After"] == item["sha256"].upper()
        record["status"] = "PASS" if okay else "FAILED CHECK"
        record["artifacts"] = [{"path": path.relative_to(root).as_posix(), "sha256": digest(path)}
                               for path in sorted(output.parent.glob(output.stem + ".*")) if path.is_file()]
        write(records / (name + ".json"), record)
        summary["modules"].append(record)
        write(records / "build-summary.json", summary)
        print(f"{index}/{len(order)} {name}: {record['status']}", flush=True)
        if not okay:
            summary.update(status="FAILED CHECK", finishedUtc=utc())
            write(records / "build-summary.json", summary)
            return 1
    for item in modules.values():
        require(digest(inside(root, item["source"])) == item["sha256"].upper(),
                "Source changed during the build: " + item["name"])
    summary.update(status="SOURCE BUILD COMPLETE", finishedUtc=utc())
    write(records / "build-summary.json", summary)
    print("SOURCE BUILD COMPLETE. Fresh kernel replay and final identity/axiom checks remain to be run.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print("SOURCE BUILD NOT COMPLETED: " + str(error), file=sys.stderr)
        raise SystemExit(1)
